### Changelog 

[12-04-2020]

 - Project Published 
 
[13-04-2020]
 - Added Licence
 - Updated README file 
 
 [15-04-2020]
 
 - Added [GF profiles](https://github.com/devanshbatham/ParamSpider/tree/master/gf_profiles) (xss.json,potential.json,redirect.json)
 - Fixed a minor [bug](https://github.com/devanshbatham/ParamSpider/commit/55fb586ec7e38e7dfc2aae15ff4b9e949550d466) in core/save_it.py (added encoding='utf-8' while writing in output file)
 - Updated README file ([replaced pip with pip3](https://github.com/devanshbatham/ParamSpider/commit/d670606f3abef77dac10965632cec9e02406ed10))
 
 [16-04-2020]
 
 - Fixed a [small typo](https://github.com/devanshbatham/ParamSpider/commit/c174799f8877dd642bc8ed48d144247791017126) in paramspider.py
 - Fixed a [minor bug](https://github.com/devanshbatham/ParamSpider/commit/2ff597e67622878c083e6838056ab3d5471973f1) (bug was triggered when the script was failing to make a request to web archive cdx api)
 - Added [wordpress.json](https://github.com/devanshbatham/ParamSpider/commit/69b0612b0d652beb434b987c22e39293fe1f2f66) in GF profiles
 - Added support for [custom placeholder](https://github.com/devanshbatham/ParamSpider/commit/fedc0281cb8ad832efad5f936f0e577cd98a5467)
